# List of features can be added

* Add Resumes
* Update Resumes
* Create data model for a Resume
* Create tags for technology, experience from a Resume
* Categorise resume
* Email applicant
* Analytics dashboard
* Export reports
* Cleaning the sourcecode for runtime optimization
* Custom Weigth Score For Analyst 
* Support Query Applicant's Data From Search Engine
* Create blacklist for spam resumes
* Face recognition to verify identity
* Automated checking of previous job experiences ligetimacy
* Crawler for relevant information about the applicant
